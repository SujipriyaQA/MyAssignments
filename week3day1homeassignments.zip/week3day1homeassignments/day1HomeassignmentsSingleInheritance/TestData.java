package week3.day1HomeassignmentsSingleInheritance;

public class TestData {
	
	public void enterCredentials() {
		System.out.println("enterCredentials");
	}
	
	public void navigateToHomePage() {
		System.out.println("navigateToHomePage");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
