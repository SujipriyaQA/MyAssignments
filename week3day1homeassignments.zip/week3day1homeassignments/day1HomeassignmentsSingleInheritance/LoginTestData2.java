package week3.day1HomeassignmentsSingleInheritance;

public class LoginTestData2 extends TestData {

	public void enterUsername() {
		System.out.println("enterUsername");
	}
	
	public void enterPassword() {
		System.out.println("enterPassword");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginTestData2 obj2 = new LoginTestData2();
		obj2.enterCredentials();
		obj2.enterUsername();
		obj2.enterPassword();
		obj2.navigateToHomePage();

	}

}
