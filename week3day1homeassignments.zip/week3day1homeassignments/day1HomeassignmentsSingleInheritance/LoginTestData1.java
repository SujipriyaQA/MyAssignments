package week3.day1HomeassignmentsSingleInheritance;

public class LoginTestData1 extends TestData {

	public void enterUsername() {
		System.out.println("enterUsername");
	}
	
	public void enterPassword() {
		System.out.println("enterPassword");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginTestData1 obj1 = new LoginTestData1();
		obj1.enterCredentials();
		obj1.enterUsername();
		obj1.enterPassword();
		obj1.navigateToHomePage();
	}

}
