package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class DIInJavaRadioButton extends DIInJavaButton{
	
	
	public void selectRadioButton() {
		System.out.println("selectRadioButton");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
