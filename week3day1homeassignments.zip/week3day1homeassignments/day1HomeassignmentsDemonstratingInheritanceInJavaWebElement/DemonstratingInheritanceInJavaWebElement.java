package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class DemonstratingInheritanceInJavaWebElement {
	
	public void click() {
		System.out.println("Click");
	}
	public void setText(String text){
		System.out.println(text);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
