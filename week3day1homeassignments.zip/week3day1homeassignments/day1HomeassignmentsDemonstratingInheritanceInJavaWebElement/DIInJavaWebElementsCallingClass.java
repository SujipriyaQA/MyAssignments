package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class DIInJavaWebElementsCallingClass extends DIInJavaButton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DIInJavaWebElementsCallingClass elobj = new DIInJavaWebElementsCallingClass();
		elobj.click();
		elobj.setText("Hello");
		elobj.submit();
		
		DIInJavaTextField textfobj = new DIInJavaTextField();
		textfobj.getText();
		
		DIInJavaCheckBoxButton checobj = new DIInJavaCheckBoxButton();
		checobj.clickCheckButton();
		

	}

}
