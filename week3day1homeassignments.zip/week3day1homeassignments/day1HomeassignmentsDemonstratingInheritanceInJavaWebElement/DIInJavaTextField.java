package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class DIInJavaTextField extends DemonstratingInheritanceInJavaWebElement {

	
	public void getText() {
		System.out.println("getText");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
