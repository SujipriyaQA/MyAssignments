package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class BasePage {

	public void findElement() {
		System.out.println("findElement");
	}
	
	public void clickElement() {
		System.out.println("clickElement");
	}
	
	public void enterText() {
		System.out.println("enterText");
	}
	
	public void performCommonTasks() {
		System.out.println("Base performCommonTasks");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
