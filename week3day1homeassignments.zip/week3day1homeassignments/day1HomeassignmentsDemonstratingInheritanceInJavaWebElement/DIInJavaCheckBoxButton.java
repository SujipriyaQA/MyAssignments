package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class DIInJavaCheckBoxButton extends DIInJavaButton{

	
	public void clickCheckButton() {
		System.out.println("clickCheckButton");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
