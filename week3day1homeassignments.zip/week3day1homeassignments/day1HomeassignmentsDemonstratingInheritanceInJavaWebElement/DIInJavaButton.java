package week3.day1HomeassignmentsDemonstratingInheritanceInJavaWebElement;

public class DIInJavaButton extends DemonstratingInheritanceInJavaWebElement {
	
	public void submit() {
		System.out.println("submit");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
