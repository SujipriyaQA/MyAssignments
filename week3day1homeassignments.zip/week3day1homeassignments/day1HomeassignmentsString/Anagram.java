package week3.day1HomeassignmentsString;

import java.util.Arrays;

import org.checkerframework.checker.index.qual.LengthOf;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text1 = "stops";
		String text2 = "potss";
		if (text1.length() == text2.length()) {
			System.out.println("They are same in character count");
			char[] chr1 = text1.toCharArray();
			System.out.println(chr1);
			char[] charArray2 = text2.toCharArray();
			System.out.println(charArray2);
			Arrays.sort(chr1);
			Arrays.sort(charArray2);
			System.out.println(chr1);
			System.out.println(charArray2);
			// boolean i = chr1.equals(charArray2);
			if (String.valueOf(chr1).equals(String.valueOf(charArray2))) {
				System.out.println("They are same, its an Anagram");
			} else {
				System.out.println("They are not same, its not an Anagram");
			}
		}

		else {
			System.out.println("The length are diff, so they are not Anagram");
		}

	}

}
