package week3.day1HomeassignmentsString;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplWordsShort {
	public static void main(String[] args) {
        // Example input sentence
        String sentence = "We learn Java basics as part of java sessions in java week1";
        
        // Call the function to remove duplicate words
        String result = removeDuplicates(sentence);
        
        // Print the result
        System.out.println("Original Sentence: " + sentence);
        System.out.println("Sentence after removing duplicates: " + result);
    }

    // Function to remove duplicate words
    public static String removeDuplicates(String sentence) {
        // Split the sentence into words using space as a delimiter
        String[] words = sentence.split("\\s+");

        // Use a LinkedHashSet to maintain insertion order and remove duplicates
        Set<String> wordSet = new LinkedHashSet<>(Arrays.asList(words));

        // Join the set back into a sentence
        return String.join(" ", wordSet);
}
}