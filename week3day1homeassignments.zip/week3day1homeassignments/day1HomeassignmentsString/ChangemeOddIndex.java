package week3.day1HomeassignmentsString;

import org.checkerframework.checker.index.qual.LengthOf;

public class ChangemeOddIndex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String test = "changeme";
		char[] charArray = test.toCharArray();
		
		int j = charArray.length;
		for(int i=0, len = j; i<len; i++ )
		{
			char ch =test.charAt(i);
			
			if(i%2==0) 
			{
				System.out.print(Character.toUpperCase(ch));
			}
			else {
				
				System.out.print(Character.toLowerCase(ch));
			}
			
			
		}
		
	}

}
