package week3.day1HomeassignmentsString;

public class ReverseOddWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sen = "I am a software tester";
		//sen = sen.toLowerCase();
        String[] arr = sen.split(" ");
        String r = 	"";
        for(int i=0;i<arr.length; i++)
        {
        	if(i%2==0)
        	{
        		for ( int j=arr[i].length()-1; j>=0; j--)
        		{
        			char c=arr[i].charAt(j);
        			r=""+c;
        			System.out.print(r);
        		}
        		System.out.println();
        		
        	}
        }
	}

}
