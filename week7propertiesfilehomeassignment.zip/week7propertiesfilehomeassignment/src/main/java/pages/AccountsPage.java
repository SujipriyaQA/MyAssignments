package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class AccountsPage extends ProjectSpecificMethod{

	public CreateAccountPage clickCreateAccount() {
		driver.findElement(By.linkText(prop.getProperty("createAccountLink"))).click();
		return new CreateAccountPage();
	}

	
}
