package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class CreateAccountPage extends ProjectSpecificMethod{
	
	
	/*
	enterAccountName()
	driver.findElement(By.id("accountName")).sendKeys("yeshua");
	enterDescription()
	driver.findElement(By.name("description")).sendKeys("Selenium Automation Tester");
	enterOfficeSiteName()
	driver.findElement(By.id("officeSiteName")).sendKeys("LeafTaps");
	enterNumberOfEmployees()
	driver.findElement(By.id("numberEmployees")).sendKeys("200");
	clickSubmit()
	driver.findElement(By.className("smallSubmit")).click();*/
	
	
	public CreateAccountPage enterAccountName() {
		driver.findElement(By.id("accountName")).sendKeys("yeshua");
		return this;
	}
	public CreateAccountPage enterDescription() {
		driver.findElement(By.name("description")).sendKeys("Selenium Automation Tester");
		return this;
	}
	public CreateAccountPage enterOfficeSiteName() {
		driver.findElement(By.id("officeSiteName")).sendKeys("LeafTaps");
		return this;
	}
	public CreateAccountPage enterNumberOfEmployees() {
		driver.findElement(By.id("numberEmployees")).sendKeys("200");
		return this;
	}
	public CreateAccountPage clickSubmit() {
		driver.findElement(By.className("smallSubmit")).click();
		return this;
	}

}
