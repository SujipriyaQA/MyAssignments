package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

import java.lang.String;

public class TC_003_CreateAccount extends ProjectSpecificMethod{

	
		@Test
		
		public void runCreateAccount()  {
			LoginPage lp  = new LoginPage();
			/*
			 * lp.enterUsername(); lp.enterPassword(); lp.clickLoginButton();
			 */
			lp.enterUsername()
			.enterPassword()
			.clickLoginButton()
			.clickCrmsfaLink()
			.clickAcountsTab()
			.clickCreateAccount()
			.enterAccountName()
			.enterDescription()
			.enterOfficeSiteName() 
			.enterNumberOfEmployees()
			.clickSubmit();
			
		
		/*
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		driver.findElement(By.id("username")).sendKeys("DemoCSR");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
		
		
		driver.findElement(By.linkText("CRM/SFA")).click();
		clickAccountsTab()
		driver.findElement(By.linkText("Accounts")).click();
		clickCreateAccount()
		driver.findElement(By.linkText("Create Account")).click();
		enterAccountName()
		driver.findElement(By.id("accountName")).sendKeys("yeshua");
		enterDescription()
		driver.findElement(By.name("description")).sendKeys("Selenium Automation Tester");
		enterOfficeSiteName()
		driver.findElement(By.id("officeSiteName")).sendKeys("LeafTaps");
		enterNumberOfEmployees()
		driver.findElement(By.id("numberEmployees")).sendKeys("200");
		clickSubmit()
		driver.findElement(By.className("smallSubmit")).click();
		
		//String title= driver.getTitle();
		//System.out.println("The Tile is "+ title);
		//System.out.println(driver.getTitle());
		String s= driver.getTitle();
		System.out.println(s);
		driver.close();

	*/
		}
}
