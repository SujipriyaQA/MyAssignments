package week1.day1HomeAssignments;

public class Chrome {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
		
		float version = 91f;
		String developer = "Google";
		boolean isBeta = false;
		int releaseYear = 2008;
		char shortCutKey = 'c';
		System.out.println("The Version is "+ version);
		System.out.println("The Developer is "+ developer);
		System.out.println("The Beta is "+ isBeta);
		System.out.println("The Release Year is "+ releaseYear);
		System.out.println("The Short Cut Key is "+ shortCutKey);
	}

}
