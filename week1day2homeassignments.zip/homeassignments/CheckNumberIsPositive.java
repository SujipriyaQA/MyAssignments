package week1.day2.homeassignments;

public class CheckNumberIsPositive {
	/*
	 * public static String pst() { System.out.println("hi"); return; }
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// pst();

		int value = 10;
		if (value < 0) {
			System.out.println("The Given value " + value + " is Negative");
		} else {
			System.out.println("The Given value " + value + " is Positive");
		}

		// self practice on String

		int im = 5, j = 2;
		System.out.println(im % j);
		char c = 65;
		// System.out.println('c= '+c);

		int temp = 0;
		for (int i = 1; i <= 10; i++)
			;
		temp += 1;
		System.out.println(temp);

		int myArr[] = new int[0];
		System.out.println(myArr);
		String ar = "ji";
		String jr = "jin";
		ar.concat(jr);
		System.out.println(ar);

	}

}
