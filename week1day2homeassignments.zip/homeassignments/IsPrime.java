package week1.day2.homeassignments;

public class IsPrime {
//Prime numbers between 1 and 100:
//2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 
//41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 89, count = 0;

		if (num < 2) {
			System.out.println("The given number " + num + " is not prime");
		}

		for (int i = 1; i <= num; i++) {
			if (num % i == 0) {
				// System.out.println(count);
				count = count + 1;
				// System.out.println(count);
			}
		}
		if (count == 2) {
			System.out.println("The given num " + num + " is a prime");
		}

		else {
			System.out.println("The given number " + num + " is not prime");
		}
	}

}
