package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LogOutPage extends ProjectSpecificMethod{

	public LogOutPage(ChromeDriver driver) {
		this.driver =driver;
	}
	public void clickLogoutButton1() {
		driver.findElement(By.xpath("//*[@class='decorativeSubmit']")).click();
		//return this;
	}
	
}
