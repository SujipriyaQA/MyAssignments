package testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_Login extends ProjectSpecificMethod{

	/*public TC_001_Login(ChromeDriver driver) {
		this.driver =driver;
	}*/
	@Test
	public void runLogin() {
		LoginPage lp  = new LoginPage(driver);
		/*
		 * lp.enterUsername(); lp.enterPassword(); lp.clickLoginButton();
		 */
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton();
	}
	
}
