package testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.LogOutPage;

public class TC_003_Logout extends ProjectSpecificMethod{
	/*public TC_003_Logout(ChromeDriver driver) {
		this.driver =driver;
	}*/
	@Test
	public void runLogOut() {
		LoginPage lp  = new LoginPage(driver);
		LogOutPage lo = new LogOutPage(driver);
		/*
		 * lp.enterUsername(); lp.enterPassword(); lp.clickLoginButton();
		 */
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLogoutButton();
		lo.clickLogoutButton1();
	}
	
}

